//
//  SecondVC.swift
//  Navigation Bar
//
//  Created by MAC on 30/06/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit

class SecondVC: UIViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()
//        backItemBtn.setBackgroundVerticalPositionAdjustment(200, for: .default)
        navigationItem.title = "Hello"
        
       let image = UIImage(named: "back2")
       let baselineImage = image?.withBaselineOffset(fromBottom: 16)
        
        let rightBarButton = UIBarButtonItem(image: baselineImage, style: .done, target: self, action: #selector(self.changToBack(_:)))
        self.navigationItem.rightBarButtonItem = rightBarButton
//        rightBarButton.tintColor = .green
        let leftBarButton = UIBarButtonItem(title: "back", style: .done, target: self, action: #selector(self.changToBack(_:)))
        self.navigationItem.leftBarButtonItem = leftBarButton
//        rightBarButton.tintColor = .green
    
//        let img = UIImage(named: "back2")
//        backItemBtn.setBackgroundImage(img, for: .normal, barMetrics: .default)
//        backItemBtn.tintColor = .blue
////        backItemBtn.setTitlePositionAdjustment(UIOffset(horizontal: 30, vertical: 30), for: UIBarMetrics.default)
//        backItemBtn.target = self
//        backItemBtn.action = #selector(changToBack(_:))
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    @IBAction func changToBack(_ sender: UIBarButtonItem)
    {
//        self.dismiss(animated: true, completion: nil)
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func changeAction(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
//        self.dismiss(animated: true, completion: nil)
        
    }
 
    
}
