//
//  ViewController.swift
//  Navigation Bar
//
//  Created by MAC on 30/06/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UINavigationBarDelegate, UINavigationControllerDelegate {
    
//    @IBOutlet weak var navigationBar: UINavigationBar!
    
    @IBOutlet weak var btn: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.delegate = self
        navigationItem.title = "Welcome"
        navigationController?.navigationBar.tintColor = .white
//        navigationController?.navigationBar.isTranslucent = true
//        navigationController?.navigationBar.isHidden = true
        navigationController?.navigationBar.barTintColor = .brown
        navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor : UIColor.blue]
        let rightBarButton = UIBarButtonItem(title: "Help", style: .done, target: self, action: #selector(self.ClickToOpen(_:)))
        navigationItem.leftBarButtonItem = rightBarButton
        
        
//        navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor : UIColor.white]
        // Do any additional setup after loading the view.
    }

    @IBAction func ClickToOpen(_ sender: UIBarButtonItem) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ThirdVC") as! ThirdVC
//        self.navigationController?.pushViewController(vc, animated: true)

        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func changeAction(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SecondVC") as! SecondVC
        self.navigationController?.pushViewController(vc, animated: true)
//        vc.modalPresentationStyle = .overCurrentContext
//        self.present(vc, animated: true, completion: nil)
        
    }
    func navigationBar(_ navigationBar: UINavigationBar, shouldPush item: UINavigationItem) -> Bool
    {
        print("shouldPush")
        return true
    }
    
    func navigationBar(_ navigationBar: UINavigationBar, didPush item: UINavigationItem)
    {
        print("didPush")
    }
    
    func navigationBar(_ navigationBar: UINavigationBar, shouldPop item: UINavigationItem) -> Bool
    {
        print("shouldPop")
        return true
    }

    func navigationBar(_ navigationBar: UINavigationBar, didPop item: UINavigationItem)
    {
        print("didPop")

    }
    func navigationController(_ navigationController: UINavigationController, willShow viewController: UIViewController, animated: Bool) {
        print("willshow")
    }
    func navigationController(_ navigationController: UINavigationController, didShow viewController: UIViewController, animated: Bool) {
        print("didshow")
    }
}

